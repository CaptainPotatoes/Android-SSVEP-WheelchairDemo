//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: classifySSVEP3_types.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 07-Jun-2017 12:50:12
//
#ifndef CLASSIFYSSVEP3_TYPES_H
#define CLASSIFYSSVEP3_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for classifySSVEP3_types.h
//
// [EOF]
//
