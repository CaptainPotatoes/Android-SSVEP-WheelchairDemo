//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: classifySSVEP_types.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 22-May-2017 11:55:35
//
#ifndef CLASSIFYSSVEP_TYPES_H
#define CLASSIFYSSVEP_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for classifySSVEP_types.h
//
// [EOF]
//
